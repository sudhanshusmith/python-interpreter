s = "123"
print(s)
print(s[3:4])